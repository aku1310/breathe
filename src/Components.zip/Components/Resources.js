import React from 'react'

const Resources = () => {
  return (
    <div id="resources" className="page">
        <div id="resources-card">
            <div id="resource-card-header">
                <h3>Resources</h3>
            </div>
            <div id="resource-options">
              <a target="_blank" href="http://www.pixelthoughts.co/#"><button class="resource-buttons" id="pixel-btn">Pixel Thoughts</button></a>
              
              <a target="_blank" href="http://weavesilk.com/"><button class="resource-buttons" id="silk-btn">Weave Silk</button></a>
              
              <a target="_blank" href="https://asoftmurmur.com/"><button class="resource-buttons" id="soft-btn">Soft Murmur</button></a>
              
            </div>
        </div>
        <div id="resource-page-image">
            <img id="imgHead2" src="https://cdn.discordapp.com/attachments/934093506773938277/965141584972775434/image7.png" alt="messed-brain" />
        </div>
    </div>
  )
}

export default Resources