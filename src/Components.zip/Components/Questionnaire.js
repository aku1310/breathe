import React, { Component } from "react";
import Questionjson from './Questionjson'

const Questionnaire = () => {

  const Questions = Questionjson

  return (
    <div id="questionnaire" className="page">
      <div className="inner-box">
        <form action="">
          <ol>
            <li>
            Feeling nervous, anxious or on edge
            </li>
          </ol>
        </form>
      </div>
    </div>
  )
}

export default Questionnaire